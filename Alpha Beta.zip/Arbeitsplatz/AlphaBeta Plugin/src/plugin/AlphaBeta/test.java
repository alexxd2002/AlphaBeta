package plugin.AlphaBeta;

public class test {

}
